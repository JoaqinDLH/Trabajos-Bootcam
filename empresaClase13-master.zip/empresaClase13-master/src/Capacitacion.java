package PACKAGE_NAME;public class Capacitacion {
}
